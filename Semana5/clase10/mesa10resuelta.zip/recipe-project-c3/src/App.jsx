import { useState } from 'react'
import './App.css'
import CatFetch from './Components/PokeFetch'
import DogFetch from './Components/DogFetch'
import PokeFetch from './Components/PokeFetch'


function App() {
 
  
  return (
    <>
      <PokeFetch/>
   </>
  )
}

export default App
